To run this program, ensure C is downloaded on your computer 
with a compatible compiler like gcc 

run these command to compile and run the program
% gcc filecopy.c -o filecopy
% ./filecopy input.txt copy.txt

The program will send a successfull message or an error